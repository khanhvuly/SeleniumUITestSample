﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
//using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;

namespace SeleniumUITesting
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            // Set desired capabilities to Ignore IEDriver zoom level settings and disable native events.
            DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
            caps.setCapability("EnableNativeEvents", false);
            caps.setCapability("ignoreZoomSetting", true);
            var driver = new InternetExplorerDriver();//ChromeDriver();
            driver.Navigate().GoToUrl("http://www.ultimateqa.com");
            

            /*
             *  Test method SeleniumUITesting.UnitTest1.TestMethod1 threw exception: 
    System.InvalidOperationException: Unexpected error launching Internet Explorer. Browser zoom level was set to 125%. It should be set to 100% (SessionNotCreated)
    */
        }
    }
}
